# Phone listening examples

Six fixed paper-selected room/mode pairs: P1, P2, P3 in the Medium-size meeting room and Highly reverberant hallway. These are a fixed subset of the eight modes now shown in the paper figure, chosen without listening-based selection.

Every file is mono 44.1-kHz IEEE float WAV, one second long. Both the recorded-clap input and inferred RIR use the original inference interval and alignment. Each file is independently peak-normalized to -1 dBFS for playback only. No denoising, filtering, model rerun, or additional cropping was applied. This playback normalization was not used for inference or spectral analysis. Original peaks, gains, source files, repetitions, and hashes are in the manifest. No paired reference RIR exists; these examples support listening inspection, not reconstruction accuracy.
